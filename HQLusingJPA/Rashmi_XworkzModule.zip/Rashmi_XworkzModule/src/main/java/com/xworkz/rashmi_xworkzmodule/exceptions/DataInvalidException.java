package com.xworkz.rashmi_xworkzmodule.exceptions;

public class DataInvalidException extends Throwable {
    public DataInvalidException(String msg) {
        super(msg);
    }
}
