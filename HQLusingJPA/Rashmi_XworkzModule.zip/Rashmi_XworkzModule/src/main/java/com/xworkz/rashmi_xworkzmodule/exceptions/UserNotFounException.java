package com.xworkz.rashmi_xworkzmodule.exceptions;

public class UserNotFounException extends Throwable {
    public UserNotFounException(String msg) {
        super(msg);
    }
}
