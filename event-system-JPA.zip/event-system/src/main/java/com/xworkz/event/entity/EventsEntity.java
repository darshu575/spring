package com.xworkz.event.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "events")
public class EventsEntity {
    @Id
    @Column(name = "id")
    private  int id;
    @Column(name = "organizer_name")
    private String organizerName;
    @Column(name = "time")
    private  String time;
    @Column(name = "Location")
    private  String location;
    @Column(name = "no_Of_People")
    private int noOfPeople;
}